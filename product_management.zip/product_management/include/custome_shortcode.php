<?php
// register shortcode
add_shortcode('product_list', 'pm_product_list_shortcode'); 
function pm_product_list_shortcode() { 
?>
<div class="container">
<!-- <h3 class="h3">shopping Demo-2 </h3> -->
<div class="row">
<?php	
$the_query = new WP_Query( array('posts_per_page'=>2,
                 'post_type'=>'products',
                 'paged' => get_query_var('paged') ? get_query_var('paged') : 1) 
            ); 
            ?>
<?php while ($the_query -> have_posts()) : $the_query -> the_post(); 
global $post;

$product_price = get_post_meta($post->ID, "_product_price", true);
$featured_img_url = get_the_post_thumbnail_url($post->ID,'full');

?>
<div class="col-md-3 col-sm-6">
            <div class="product-grid2">
        <div class="product-image2">
            <a href="<?php the_permalink(); ?>">
                <img class="pic-1" src="<?=$featured_img_url?>" alt="<?php echo get_the_title(); ?>" style="height: 226px;"> 
                <img class="pic-2" src="<?=$featured_img_url?>" alt="<?php echo get_the_title(); ?>" style="height: 226px;">
            </a>
            
            <a class="add-to-cart" href="<?= admin_url(); ?>admin-post.php?action=add_to_cart&id=<?=$post->ID?>">Add to cart</a>
        </div>
        <div class="product-content">
            <h3 class="title"><a href="#"><?php echo get_the_title(); ?></a></h3>
            <span class="price">$<?php echo $product_price?></span>
        </div>
    </div>
</div>
<?php
endwhile;
?>
</div>
</div>
<nav class="pagination">
<?php
$big = 999999999; // need an unlikely integer
 echo paginate_links( array(
    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'total' => $the_query->max_num_pages,
    'prev_text'    => __('«'),
    'next_text'    => __('»'),
) );
?>
</nav>
<?php
wp_reset_postdata();

} 


add_shortcode('cart_list', 'pm_cart_list_shortcode'); 
function pm_cart_list_shortcode() { 

?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-10 col-md-offset-1">
            <?php
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Total</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($_SESSION["cart_item"])) {
                        $allprice=0;
                        foreach ($_SESSION["cart_item"] as $keyData => $valueData) {
                            $img_url = get_the_post_thumbnail_url($keyData,'full');
                            $newprice=$valueData['product_price']*$valueData['quantity'];
                        ?>
                        <tr>
                        <td class="col-sm-8 col-md-6">
                        <div class="media">
                            <a class="thumbnail pull-left" href="#"> <img class="media-object" src="<?=$img_url?>" style="width: 72px; height: 72px;"> </a>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="#"><?php echo get_the_title( $keyData ); ?>
</a></h4>
                                
                            </div>
                        </div></td>
                        <td class="col-sm-1 col-md-1" style="text-align: center">
                        <input type="email" class="form-control" id="exampleInputEmail1" value="<?=$valueData['quantity']?>">
                        </td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>$<?=$valueData['product_price']?></strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>$<?=$newprice?></strong></td>
                        <td class="col-sm-1 col-md-1">
                         <a class="add-to-cart" href="<?= admin_url(); ?>admin-post.php?action=remove_cart&id=<?=$keyData?>">Remove</a></td>
                    </tr>
                        <?php
                        $allprice +=$newprice;
                        }
                    }else{
                        ?>
                        <tr>
                          <td class="col-sm-8 col-md-6">No data found.</td>
                        
                         </tr>
                        <?php
                    }

                    if (isset($_SESSION["cart_item"])) {
                        ?>
                        <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h5>Subtotal</h5></td>
                        <td class="text-right"><h5><strong>$<?=$allprice?></strong></h5></td>
                    </tr>
                    
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td><h3>Total</h3></td>
                        <td class="text-right"><h3><strong>$<?=$allprice?></strong></h3></td>
                    </tr>
                    <tr>
                        <td>   </td>
                        <td>   </td>
                        <td>   </td>
                        <td>
                        </td>
                        <td>
                        <button type="button" class="btn btn-success">
                            Checkout <span class="glyphicon glyphicon-play"></span>
                        </button></td>
                    </tr>
                        <?php
                    }
                    ?>
                    
                    
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
}

<?php
/**
 * Plugin Name: Product Management
 * Plugin URI: https://www.tatvasoft.com/
 * Description: This plugin use for create a product management.
 * Version: 1.0
 * Author: Tatvasoft
 * Author URI: https://www.tatvasoft.com/
 */
/*include js and css*/
session_start();
add_action( 'wp_enqueue_scripts', 'wpgm_wedding_scripts' );
function wpgm_wedding_scripts() {
  
  wp_enqueue_style( 'pm-bootstrap-css', plugin_dir_url(__FILE__) . 'css/bootstrap.css', array(), '3.3.7', 'all');
  wp_enqueue_style( 'pm-style-css', plugin_dir_url(__FILE__) . 'css/pm_style.css', array(), '3.3.8', 'all');
  wp_enqueue_script( 'pm-bootstrap-script', plugin_dir_url(__FILE__)  . 'js/bootstrap.js', array ( 'jquery' ), 3.7, true);
  wp_enqueue_script( 'pm-jquery-script', plugin_dir_url(__FILE__)  . 'js/jquery.min.js', array ( 'jquery' ), 3.7, true);
}
include(plugin_dir_path(__FILE__).'include/custome_post.php');
include(plugin_dir_path(__FILE__).'include/custome_meta.php');
include(plugin_dir_path(__FILE__).'include/custome_shortcode.php');

 /* Add "Custom" template for product management.*/
 
add_filter( 'theme_page_templates', 'pm_add_page_template_to_dropdown');
function pm_add_page_template_to_dropdown($template) {

    // Add custom template named template-custom.php to select dropdown 
    $template['product-template.php'] = __('Full Width', 'text-domain');

    return $template;
}

/* include hook.*/
add_filter( 'template_include', 'pm_use_template');
function pm_use_template($template) {
    if ( is_page( 'Product list' )  ) {
        $new_template = plugin_dir_path(__FILE__).'product-template.php';
	    return $new_template ;
    }else{
    	return $template;
    }
    
}
/* plugin activation hook.*/
register_activation_hook(__FILE__, 'pm_plugin_active');
function pm_plugin_active() {
	$page_title='Product list';
	$page_template='product-template.php';
	$page_content='[product_list]';

	$page_check=get_page_by_title($page_title);

    // Create post object
    $page = array(
      'post_title'    => $page_title,
      'post_content'  => $page_content,
      'post_status'   => 'publish',
      'post_author'   => 1,
      'post_type'     => 'page',
    );

    if(!isset($page_check->ID)){
    	// Insert the post into the database
        $page_id=wp_insert_post( $page );
        if ( metadata_exists( 'page', $page_id, '_wp_page_template' ) ) {
		    add_post_meta( $new_post_id, '_wp_page_template', $page_template );
		}
        
    }

    $page_cart = array(
      'post_title'    => 'Cart',
      'post_content'  => '[cart_list]',
      'post_status'   => 'publish',
      'post_author'   => 1,
      'post_type'     => 'page',
    );
    $page_cart_id=wp_insert_post( $page_cart );
    add_post_meta( $page_cart_id, '_wp_page_template', $page_template );

    
}
/*plugin deactive hook*/
register_deactivation_hook( __FILE__, 'pm_plugin_remove_page' );
function pm_plugin_remove_page() {
     global $wpdb;
     
     $page = get_page_by_path( 'Product list' );
     wp_delete_post($page->ID,true);

     $page_cart = get_page_by_path( 'Cart' );
     wp_delete_post($page_cart->ID,true);
}


add_action( 'admin_post_add_to_cart', 'add_to_cart_act' );

add_action( 'admin_post_nopriv_add_to_cart', 'add_to_cart_act' );
 
function add_to_cart_act() {
    
     global $wpdb;
     $product_id=$_REQUEST['id'];
     $product_price = get_post_meta($product_id, "_product_price", true);
     $quantity=1;
     if(!empty($quantity)) {
    
      $itemArray = array($product_id=>array('product_price'=>$product_price, 'quantity'=>$quantity));
    
      if(!empty($_SESSION["cart_item"])) {
        if(in_array($product_id,array_keys($_SESSION["cart_item"]))) {
          foreach($_SESSION["cart_item"] as $k => $v) {
              if($product_id == $k) {
                if(empty($_SESSION["cart_item"][$k]["quantity"])) {
                  $_SESSION["cart_item"][$k]["quantity"] = 0;
                }
                $_SESSION["cart_item"][$k]["quantity"] += $quantity;
              }
          }
        } else {
          $_SESSION["cart_item"] = $_SESSION["cart_item"]+$itemArray;
        }
      } else {
        $_SESSION["cart_item"] = $itemArray;
      }
    }
    $_SESSION['message'] = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> Product added to cart successfully!!</div>';
    wp_redirect( home_url('cart') );
    
}

add_action( 'admin_post_remove_cart', 'remove_cart_act' );

add_action( 'admin_post_nopriv_remove_cart', 'remove_cart_act' );
 
function remove_cart_act() {
    
     global $wpdb;
     $product_id=$_REQUEST['id'];

     if(!empty($_SESSION["cart_item"])) {

     foreach($_SESSION["cart_item"] as $k => $v) {
      
      if($product_id == $k ){
        unset($_SESSION["cart_item"][$k]);        
        if(empty($_SESSION["cart_item"]))
        unset($_SESSION["cart_item"]);

        
        
      }
        
     }
    
     $_SESSION['message'] = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> Product remove from cart successfully!!</div>';
    }else{
      $_SESSION['message'] = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error!</strong> No Product in cart !!</div>';
    }
     
     wp_redirect( home_url('cart') );
    
}


  
